//
//  postViewController.m
//  OCJAVASCRIPT
//
//  Created by sunftech on 16/2/24.
//  Copyright © 2016年 sunftech. All rights reserved.
//

#import "postViewController.h"

#define KWSCREEN [UIScreen mainScreen].bounds.size.width
#define KHSCREEN [UIScreen mainScreen].bounds.size.height

@interface postViewController ()
{
    UISwitch *_switchButton;
    NSInteger number1;
    NSInteger number2;
    NSInteger selectRow;
    UITableView *_tableView;
    CALayer *_layer;
    NSArray *_sectionArray;
}

@end

@implementation postViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor greenColor];
    
    //添加想法ideaLabel
    UILabel *ideaLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 20, KWSCREEN/3, 78)];
    ideaLabel.text = @"想法";
    ideaLabel.backgroundColor = [UIColor orangeColor];
    ideaLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:ideaLabel];
    //重置按钮resetButton
    UIButton *resetButton = [UIButton buttonWithType:UIButtonTypeCustom];
    resetButton.frame = CGRectMake(KWSCREEN/3, 20,KWSCREEN/3, 78);
    resetButton.backgroundColor = [UIColor grayColor];
    [resetButton setTitle:@"重置" forState:UIControlStateNormal];
    [resetButton addTarget:self action:@selector(resetButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:resetButton];
    //发布按钮postButton
    UIButton *postButton = [UIButton buttonWithType:UIButtonTypeCustom];
    postButton.frame = CGRectMake(KWSCREEN/3*2, 20,KWSCREEN/3, 78);
    postButton.backgroundColor = [UIColor redColor];
    [postButton setTitle:@"发布" forState:UIControlStateNormal];
    [postButton addTarget:self action:@selector(postButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:postButton];
    
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 98, KWSCREEN, 615) style:UITableViewStyleGrouped];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    [self.view addSubview:_tableView];
    _titleTextField = [[UITextField alloc]init];
    _titleTextField.frame = CGRectMake(0, 0, 375, 40);
    _titleTextField.placeholder = @"输入2-10个字的标题";
    _titleTextField.delegate = self;
    
    [self.titleTextField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    _broadcastTV = [[UITextView alloc]initWithFrame:CGRectMake(0, 0, KWSCREEN, 150)];
    _broadcastTV.delegate = self;
    
    // _placeholderLabel.frame = CGRectMake(0, 0, KWSCREEN, 20);
    // _placeholderLabel.text = @"请输入你的广播......";
    [_broadcastTV addSubview:_placeholderLabel];
    
    _switchButton = [[UISwitch alloc]initWithFrame:CGRectMake(310, 10, 40, 40)];
    [_switchButton addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
    _layer = [[CALayer alloc]init];
    _layer.frame = CGRectMake(5, 5, 30, 30);
    _layer.backgroundColor = [UIColor blueColor].CGColor;
    _layer.cornerRadius = 15;
    _sectionArray = [NSArray arrayWithObjects:@"见解",@"故事",@"需求", nil];
}

#pragma mark-
#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section ==2)
    {
        return 3;
    }else
    {
        return 1;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellWithIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellWithIdentifier];
        if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellWithIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;

    if (indexPath.section ==0) {
        
        if (_titleTextField!=nil) {
            [cell.contentView addSubview:_titleTextField];

        }
     
    }else if (indexPath.section ==1)
    {
        if (_broadcastTV!=nil) {
            [cell.contentView addSubview:_broadcastTV];
        }
        
    }else if (indexPath.section ==2)
    {
        
            UIImageView *imgViewOne = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
            imgViewOne.image = [UIImage imageNamed:@""];
            [cell.contentView addSubview:imgViewOne];
            UILabel *ideaLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 0, 80, 50)];
            ideaLabel.text = _sectionArray[indexPath.row];
            [cell.contentView addSubview:ideaLabel];
        
            
        
    }else
    {
        [cell.contentView addSubview:_switchButton];
        cell.textLabel.text = @"使用位置";
    }
    
    return cell;
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section ==0) {
        
        return [NSString stringWithFormat:@"广播标题 %ld/2至10",(long)number1];
        
    }else if (section ==1){
        
        return [NSString stringWithFormat:@"发布内容 %ld/144以上",(long)number2];
    }else if (section ==2)
    {
        return @"诉说类型";
    }else
    {
        return @"发布地点";
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    selectRow = indexPath.row;
    [_tableView reloadData];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}

#pragma mark-
#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 40;
}

#pragma mark 设置每行高度（每行高度可以不一样）
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section ==0) {
        return 34;
    }else if (indexPath.section ==1){
        return 150;
    }else if (indexPath.section ==2)
    {
        return 50;
    }else{
        return 52;
    }
    
}
- (void)resetButtonClick:(id)sender
{
    _titleTextField.text = @"";
    _broadcastTV.text = @"";
    number1=0;
    number2=0;
    [_tableView reloadData];
    NSLog(@"已删除输入的内容");
}

- (void)postButtonClick:(id)sender
{
    if (_titleTextField.text.length>=2 && _titleTextField.text.length <=10 && _broadcastTV.text.length>=144) {
        NSLog(@"符合条件");
    }
    
    NSLog(@"你输入的广播标题字数不符");
}

- (void)switchAction:(id)sender
{
    NSLog(@"打开地理位置");
}

#pragma mark-
#pragma mark UITextFieldDelegate
//限制字符串的长度为10
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField == self.titleTextField)
    {
        if (string.length == 0)
            return YES;
        NSInteger existedLength = textField.text.length;
        NSInteger selectedLength = range.length;
        NSInteger replaceLength = string.length;
        if (existedLength - selectedLength + replaceLength > 10)
        {
            return NO;
        }
        
    }
    
    return YES;
}

- (void)textFieldDidChange:(UITextField *)textField
{
    if (textField == self.titleTextField) {
        if (textField.text.length > 10) {
            textField.text = [textField.text substringToIndex:11];
        }
        else
        {
            number1 = textField.text.length;
            [_tableView reloadData];
        }
    }
    
    NSLog(@"字符串的长度改变了");
}

#pragma mark-
#pragma mark UITextViewDelegate
-(void)textViewDidChange:(UITextView *)textView

{
    // textview 改变字体的行间距
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 10;// 字体的行间距
    NSDictionary *attributes = @{
                                 NSFontAttributeName:[UIFont systemFontOfSize:20],
                                 NSParagraphStyleAttributeName:paragraphStyle
                                 };
    
    textView.attributedText = [[NSAttributedString alloc] initWithString:textView.text attributes:attributes];
    
    number2 =  textView.text.length;
    [_tableView reloadData];
    
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text

{ if (![text isEqualToString:@""])
{
    _placeholderLabel.hidden = YES;
}
    
    if ([text isEqualToString:@""] && range.location == 0 && range.length == 1)
    {
        _placeholderLabel.hidden = NO;
    }
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
    
}
@end

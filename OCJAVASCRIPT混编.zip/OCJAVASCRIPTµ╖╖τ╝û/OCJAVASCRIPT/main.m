//
//  main.m
//  OCJAVASCRIPT
//
//  Created by sunftech on 16/2/24.
//  Copyright © 2016年 sunftech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

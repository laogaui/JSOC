//
//  postViewController.h
//  OCJAVASCRIPT
//
//  Created by sunftech on 16/2/24.
//  Copyright © 2016年 sunftech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface postViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextViewDelegate,UITextFieldDelegate>

@property (nonatomic,strong)UITextField *titleTextField;
@property (nonatomic,strong)UITextView  *broadcastTV;
@property (nonatomic,strong)UILabel     *placeholderLabel;

@end

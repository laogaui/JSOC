//
//  ViewController.m
//  OCJAVASCRIPT
//
//  Created by sunftech on 16/2/24.
//  Copyright © 2016年 sunftech. All rights reserved.
//

#import "ViewController.h"
#import "ADViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>
@interface ViewController ()<UIWebViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webVc;
@property (weak, nonatomic) IBOutlet UIButton *btn;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.edgesForExtendedLayout=NO;
    NSURL *url = [NSURL URLWithString:[[NSBundle mainBundle] pathForResource:@"index.html" ofType:nil]];
    NSURLRequest *requst = [NSURLRequest requestWithURL:url];
    self.webVc.delegate = self;
    [self.webVc loadRequest:requst];
    
}
- (IBAction)btnclick:(id)sender {
    [self.webVc stringByEvaluatingJavaScriptFromString:@"printsomething()"];
//    JSContext *context=[self.webVc valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
//    
//    //js调用iOS
//    //第一种情况
//    //其中test1就是js的方法名称，赋给是一个block 里面是iOS代码
//    //此方法最终将打印出所有接收到的参数，js参数是不固定的 我们测试一下就知道
//    context[@"test1"] = ^() {
//        NSArray *args = [JSContext currentArguments];
//        for (id obj in args) {
//            NSLog(@"%@",obj);
//        }
//    };
//    //此处我们没有写后台（但是前面我们已经知道iOS是可以调用js的，我们模拟一下）
//    //首先准备一下js代码，来调用js的函数test1 然后执行
//    //一个参数
//    NSString *jsFunctStr=@"test1('参数1')";
//    [context evaluateScript:jsFunctStr];
//    
//    //二个参数
//    NSString *jsFunctStr1=@"test1('参数a','参数b')";
//    [context evaluateScript:jsFunctStr1];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSString *url = request.URL.absoluteString;
    NSLog(@"%@",url);
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    NSLog(@"开始加载");
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
        JSContext *context=[self.webVc valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    
        //js调用iOS
        //第一种情况
        //其中test1就是js的方法名称，赋给是一个block 里面是iOS代码
        //此方法最终将打印出所有接收到的参数，js参数是不固定的 我们测试一下就知道
        context[@"woyaotiao"] = ^() {
            
          
            
            NSArray *args = [JSContext currentArguments];
            
            for (JSValue *jsVal in args) {
                NSLog(@"%@", jsVal);
            }
            
            JSValue *this = [JSContext currentThis];
            NSLog(@"-----%@",this);
            
            ADViewController *adVC = [[ADViewController alloc]init];
            [self.navigationController pushViewController:adVC animated:YES];
            
            
            
        };
//    NSString *jsFunctStr=@"woyaotiao('参数1')";
//    [context evaluateScript:jsFunctStr];
//    
//    //二个参数
//    NSString *jsFunctStr1=@"woyaotiao('参数a','参数b')";
//    [context evaluateScript:jsFunctStr1];
    
    
    
    NSLog(@"加载完成");
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error
{
    NSLog(@"加载失败");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
